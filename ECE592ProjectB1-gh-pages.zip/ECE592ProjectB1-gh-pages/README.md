# ECE592ProjectB1
This repository will be used for ECE 592-081 Project B1. 

link to site:https://pages.github.ncsu.edu/wmccray/ECE592ProjectB1/
Explore this data story...
<iframe src="https://docs.google.com/document/d/e/2PACX-1vSLYfs6nF6KxXBVPxiOuYWaulCgUuwMafqvFvcF_rDPSOgX-7fJeJuQogvUYsEVO_yC9nBNbsnZpt-M/pub?embedded=true"></iframe>

