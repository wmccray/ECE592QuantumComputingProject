This Project was conducted as a completion for the course on ECE592 Quantum Computing. 

We have implemented a Quantum chemistry alogrithm to solve the adiabatic schrodinger equation using the VQE algorithm. project was simulated on various simulators to measure the difference in the measurement as well as gain an understanding of the mecahnism behind the algorithm




One of the dependencies is not avalable for Windows so it is recommended that Linux is used to run the Quantum Chemistry simulation. 

The following dependacies are required to run the Quantum Chemistry Simulation:
Qiskit
NumPy
PySCF

Assuming Python, Jupyter Notebook, and Pip are aleady installed, type the following command into the Linux terminal window to install Qiskit: "pip install qiskit"


Type the following command into the Linux terminal window to install NumPy: "pip install numpy"


Type the following command into the Linux terminal window to install PySCF: "pip install pyscf"


Once the Jupyter Notebook is open and the dependencies have been installed, the script can be ran inside the Jupyter notebook one section at a time from top to bottom. There are comments in the Jupyter notebook explaining what each section of the script does. 
